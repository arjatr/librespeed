<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no" />
<title>WIKIVPS-SPEEDTEST</title>
<link rel="shortcut icon" href="favicon.ico">
<script type="text/javascript" src="speedtest.js"></script>
<script type="text/javascript">

//INITIALIZE SPEEDTEST
var s=new Speedtest(); //create speedtest object
s.onupdate=function(data){ //callback to update data in UI
    I("ip").textContent=data.clientIp;
    I("dlText").textContent=(data.testState==1&&data.dlStatus==0)?"...":data.dlStatus;
    I("ulText").textContent=(data.testState==3&&data.ulStatus==0)?"...":data.ulStatus;
    I("pingText").textContent=data.pingStatus;
    I("jitText").textContent=data.jitterStatus;
    var prog=(Number(data.dlProgress)*2+Number(data.ulProgress)*2+Number(data.pingProgress))/5;
    I("progress").style.width=(100*prog)+"%";
}
s.onend=function(aborted){ //callback for test ended/aborted
    I("startStopBtn").className=""; //show start button again
    if(aborted){ //if the test was aborted, clear the UI and prepare for new test
		initUI();
    }
}

function startStop(){ //start/stop button pressed
	if(s.getState()==3){
		//speedtest is running, abort
		s.abort();
	}else{
		//test is not running, begin
		s.start();
		I("startStopBtn").className="running";
	}
}

//function to (re)initialize UI
function initUI(){
	I("dlText").textContent="";
	I("ulText").textContent="";
	I("pingText").textContent="";
	I("jitText").textContent="";
	I("ip").textContent="";
}

function I(id){return document.getElementById(id);}
</script>

<style type="text/css">
	    html {

        height:100%;

        width:100%;

    }

    body{
        color:#FFF;
        background:#000 url('fondo.jpg') no-repeat center center;
        background-size:100% 100%;

    } 
	body{
		text-align:center;
		font-family:"Roboto",sans-serif;
	}
	h1{
		color:#ffffff;
	}
	#startStopBtn{
  display:inline-block;
  margin:0 auto;
  color:#FFF;
  background-color:rgba(0,0,0,0);
  border:0.15em solid #6060FF;
  border-radius:50px;
  transition:all 0.3s;
  box-sizing:border-box;
  width:20em; height:3em;
  line-height:2.7em;
  cursor:pointer;
  box-shadow: 0 0 0 rgba(0,0,0,0.1), inset 0 0 0 rgba(0,0,0,0.1);
}
#startStopBtn:hover{
  box-shadow: 0 0 2em rgba(0,0,0,0.1), inset 0 0 1em rgba(0,0,0,0.1);
}
#startStopBtn.running{
  background-color:#F000;
  border-color:#F00;
  color:#FFFFFF;
}
#startStopBtn:before{
  content:"Iniciar el Test";
}
#startStopBtn.running:before{
  content:"Detener Test";
}
	#test{
		margin-top:2em;
		margin-bottom:12em;
	}
	div.testArea{
		display:inline-block;
		width:14em;
		height:9em;
		position:relative;
		box-sizing:border-box;
	}
	div.testName{
		position:absolute;
		top:0.1em; left:0;
		width:100%;
		font-size:1.4em;
		z-index:9;
	}
	div.meterText{
		position:absolute;
		bottom:1.5em; left:0;
		width:100%;
		font-size:2.5em;
		z-index:9;
	}
	#dlText{
		color:#00F;
	}
	#ulText{
		color:#0f0;
	}
	#pingText,#jitText{
		color:#AA6060;
	}
	div.meterText:empty:before{
		color:#f2eaab !important;
		content:"0.00";
	}
	div.unit{
		position:absolute;
		bottom:2em; left:0;
		width:100%;
		z-index:9;
	}
	div.testGroup{
		display:inline-block;
	}
	@media all and (max-width:65em){
		body{
			font-size:1.5vw;
		}
	}
	@media all and (max-width:40em){
		body{
			font-size:0.8em;
		}
		div.testGroup{
			display:block;
			margin: 0 auto;
		}
	}
	#progressBar{
		width:90%;
		height:0.3em;
		background-color:#EEEEEE;
		position:relative;
		display:block;
		margin:0 auto;
		margin-bottom:2em;
	}
	#progress{
		position:absolute;
		top:0; left:0;
		height:100%;
		width:0%;
		transition: width 2s;
		background-color:#f00303;
	}
		#privacyPolicy{
        position:fixed;
        top:2em;
        bottom:2em;
        left:2em;
        right:2em;
        overflow-y:auto;
        width:auto;
        height:auto;
        box-shadow:0 0 3em 1em #000000;
        z-index:999999;
        text-align:left;
        background-color:#000000bd;
        padding:1em;
		text-align:center;
	}
		#infoip{
        position:fixed;
        top:2em;
        bottom:2em;
        left:2em;
        right:2em;
        overflow-y:auto;
        width:auto;
        height:auto;
        box-shadow:0 0 3em 1em #000000;
        z-index:999999;
        text-align:left;
        background-color:#000000bd;
        padding:1em;
		text-align:center;
	}

</style>
</head>
<body>
<h1>WIKIVPS-SPEEDTEST </h1>

    <div id="progressBar"><div id="progress"></div></div>
	<div class="testGroup">
		<div class="testArea">
			<div class="testName">Download</div>
			<div id="dlText" class="meterText"></div>
			<div class="unit">Mbps</div>
		</div>
		<div class="testArea">
			<div class="testName">Upload</div>
			<div id="ulText" class="meterText"></div>
			<div class="unit">Mbps</div>
		</div>
	</div>
	<div class="testGroup">
		<div class="testArea">
			<div class="testName">Ping</div>
			<div id="pingText" class="meterText"></div>
			<div class="unit">ms</div>
		</div>
		<div class="testArea">
			<div class="testName">Jitter</div>
			<div id="jitText" class="meterText"></div>
			<div class="unit">ms</div>
		</div>
		
	</div>

<br></br>
		<div id="ipArea" style="color:#ffffff;">
			<span id="ip"></span> <a class="prc" href="#" onclick="I('infoip').style.display=''" ><font color ="#2ca5d5" > Ver Mas</font></a> <br>&nbsp <br></br>
			<div id="infoip" style="display:none">
<h2>INFORMACION DE IP</h2>			
<?php
$dip = $_SERVER['REMOTE_ADDR'];
$json = file_get_contents("https://ipinfo.io/".$dip);
$details = json_decode($json,true);
if(array_key_exists("ip",$details)) $ip.=$details["ip"];  
if(array_key_exists("city",$details)) $city.=$details["city"];
if(array_key_exists("region",$details)) $region.=$details["region"];
if(array_key_exists("country",$details)) $country.=$details["country"];
if(array_key_exists("loc",$details)) $loc.=$details["loc"];
if(array_key_exists("org",$details)) $org.=$details["org"];
if(array_key_exists("postal",$details)) $postal.=$details["postal"];

echo "Direcci&#243;n IP: " .$ip."<br>";
echo "Ciudad: " .$city."<br>";
echo "Regi&#243;n: " .$region."<br>";
echo "Pa&#237;s: " .$country."<br>";
echo "Postal: " .$postal."<br>";
echo "Localizaci&#243;n: ".$loc."<br>";
echo "Proveedor de internet: ".$org."<br>";
?>
<p></p>
    <a class="prc" href="#" onclick="I('infoip').style.display='none'"><font color ="#FF0000" >CERRAR</font></a><br/>
	
		</div>
		<div id="startStopBtn" onclick="startStop()"></div>
	</div>
<br></br>
<div class="title_footer">Test de Velocidad by FABYNEET <a class="privacy" href="#" onclick="I('privacyPolicy').style.display=''"><font color ="#E89800" >Contactarme</font></a> </div>
<h1></h1>



</div>

		
<div id="privacyPolicy" style="display:none">
    <h2>CONTACTO</h2>
    <p>MI CORREO : fabyneet@gmail.com</p>
    <p>MI TELEGRAM : https://t.me/fabyneet</p>
    <h4>Gracias por usar mi test</h4>
    <p>

    <br/><br/>
    <a class="privacy" href="#" onclick="I('privacyPolicy').style.display='none'"><font color ="#FF0000" >CERRAR</font></a><br/>
</div>
<script type="text/javascript">setTimeout(function(){initUI()},100);</script>

</body>
</html>
